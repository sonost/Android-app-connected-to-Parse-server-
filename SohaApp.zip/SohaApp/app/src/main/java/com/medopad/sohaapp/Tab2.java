package com.medopad.sohaapp;


import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.List;

public class Tab2 extends ListActivity {

    protected List<ParseObject> mbook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab2);
    }

    @Override
    protected void onResume() {
        super.onResume();

        ParseQuery<ParseObject> query = new ParseQuery<ParseObject>("Book").whereMatches("UserId", ParseUser.getCurrentUser().getObjectId());
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> booklist, ParseException e) {
                if (e == null) {
                    mbook = booklist;
                    //attach the adapter to the list view (bind the array list to the list view)
                    BookAdapter adapter = new BookAdapter(getListView().getContext(), mbook);
                    setListAdapter(adapter);
                }

            }
        });

    }
}
