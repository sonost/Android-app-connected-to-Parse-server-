package com.medopad.sohaapp;


import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import org.w3c.dom.Text;

import java.util.Calendar;
import java.util.Date;

public class Tab3 extends Activity {
    
    private Button btnEditSave;
    private EditText mName;
    private TextView mDoB;


    private Date currentDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab3);

        btnEditSave = findViewById(R.id.btnEditSave);
        mName = findViewById(R.id.editName);
        mDoB = findViewById(R.id.editDoB);

        String Name = ParseUser.getCurrentUser().getString("Name");
        currentDate = ParseUser.getCurrentUser().getDate("DoB");


        if (Name != null)
            mName.setText(Name);
        if (currentDate != null)
            mDoB.setText(android.text.format.DateFormat.format("dd MMM yyyy", currentDate));

        btnEditSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (btnEditSave.getText().toString().equals("Edit")) {
                    btnEditSave.setText("Save");
                    mName.setEnabled(true);
                    mDoB.setEnabled(true);
                } else {
                    mName.setText(mName.getText().toString().trim());
                    ParseUser.getCurrentUser().put("Name", mName.getText().toString().trim());
                    if (currentDate != null)
                        ParseUser.getCurrentUser().put("DoB", currentDate);
                    ParseUser.getCurrentUser().saveInBackground(new SaveCallback() {
                        @Override
                        public void done(ParseException e) {
                            if (e == null) {
                                btnEditSave.setText("Edit");
                                mName.setEnabled(false);
                                mDoB.setEnabled(false);
                            } else {
                                Toast.makeText(Tab3.this, "There was an error saving new Profile details", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });

        mDoB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(Tab3.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(year, monthOfYear, dayOfMonth, 0, 0, 0);
                        mDoB.setText(android.text.format.DateFormat.format("dd MMM yyyy", newDate));
                        currentDate = newDate.getTime();
                    }

                }, currentDate == null ? 2000 : currentDate.getYear() + 1900, currentDate == null ? 0 : currentDate.getMonth(), currentDate == null ? 1 : currentDate.getDate());
                datePickerDialog.show();
            }
        });

    }
}
