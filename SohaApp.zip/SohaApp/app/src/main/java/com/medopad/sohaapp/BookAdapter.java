package com.medopad.sohaapp;

import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.DeleteCallback;
import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseObject;

import java.util.List;

public class BookAdapter extends ArrayAdapter<ParseObject> {


    protected Context mContext;
    protected List<ParseObject> mBooks;

    public BookAdapter(@NonNull Context context, List<ParseObject> book) {
        super(context, R.layout.book_list_item, book);
        mContext = context;
        mBooks = book;

    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.book_list_item, null);
            holder = new ViewHolder();
            holder.bookname = (TextView) convertView.findViewById(R.id.bookname);
            holder.booknum = (TextView) convertView.findViewById(R.id.bookisbn);
            holder.bookcat = (TextView) convertView.findViewById(R.id.bookcat);
            holder.ivDelete = (ImageView) convertView.findViewById(R.id.ivDelete);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final ParseObject bookObject = mBooks.get(position);

        String bookName = bookObject.getString("Name");
        holder.bookname.setText(bookName);

        String bookNum = bookObject.getString("ISBN");
        holder.booknum.setText(bookNum);

        String bookCat = bookObject.getString("Category");
        holder.bookcat.setText(bookCat);

        holder.ivDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setMessage("Are you sure you want to delete this book?");
                builder.setTitle("Confirmation");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialogInterface, int which) {
                        bookObject.deleteInBackground(new DeleteCallback() {
                            @Override
                            public void done(ParseException e) {
                                if (e == null) {
                                    BookAdapter.this.remove(bookObject);
                                    BookAdapter.this.notifyDataSetChanged();
                                } else {
                                    Toast.makeText(getContext(), "Error deleting the book", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                        dialogInterface.dismiss();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        dialogInterface.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });
        return convertView;
    }


    public static class ViewHolder {
        TextView bookname;
        TextView booknum;
        TextView bookcat;
        ImageView ivDelete;
    }
}
