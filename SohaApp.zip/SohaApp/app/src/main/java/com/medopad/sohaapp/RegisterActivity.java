package com.medopad.sohaapp;


import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    // private EditText mName;
    private EditText mEmail;
    private EditText mPassword;

    private Button mRegisterButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        /*Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("APPLICATION_ID")
                // if desired
                .clientKey(null)
                .server("http://localhost:1337/parse//")
                .build()
        );*/

        mEmail = (EditText) findViewById(R.id.email);
        mPassword = (EditText) findViewById(R.id.password);
        mRegisterButton = (Button) findViewById(R.id.email_sign_up_button);

        //listen to register click
        mRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(RegisterActivity.this, "hi", Toast.LENGTH_LONG).show();

                String email = mEmail.getText().toString();
                String password = mPassword.getText().toString();

                //email pattern
                Pattern pattern = Pattern.compile(".+@.+\\.[a-z]+");
                Matcher matcher = pattern.matcher(email);

                if (!matcher.matches()) {
                    Toast.makeText(RegisterActivity.this, "Error, invalid email address", Toast.LENGTH_LONG).show();
                    return;
                }

                //check if pass is not null
                if (password.length() == 0) {
                    Toast.makeText(RegisterActivity.this, "Error, password can't be empty", Toast.LENGTH_LONG).show();
                    return;
                }

                //store user to parse
                ParseUser user = new ParseUser();
                user.setUsername(email);
                user.setPassword(password);
                user.signUpInBackground(new SignUpCallback() {
                    @Override
                    public void done(ParseException e) {
                        if (e == null) {
                            //successfully signed up
                            Toast.makeText(RegisterActivity.this, "Success! Welcome", Toast.LENGTH_LONG).show();
                            Intent loginIntent = new Intent(RegisterActivity.this, HomeActivity.class);
                            startActivityForResult(loginIntent, 0);
                        } else {
                            Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        this.setResult(0);
        this.finish();
    }
}
