package com.medopad.sohaapp;

import com.parse.Parse;
import com.parse.ParseObject;

import android.app.Application;

public class MyParse extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("APPLICATION_ID")
                // if desired
                //.clientKey(null)
                .server("http://10.0.2.2:1337/parse/")
                .build()
        );




//        ParseObject gameScore = new ParseObject("GameScore");
//        gameScore.put("score", 1337);
//        gameScore.put("playerName", "Sean Plott");
//        gameScore.put("cheatMode", false);
//        gameScore.saveInBackground();

    }
}
