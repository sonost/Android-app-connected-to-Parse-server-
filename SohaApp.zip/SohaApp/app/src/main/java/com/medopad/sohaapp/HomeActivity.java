package com.medopad.sohaapp;

import android.app.TabActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;

@SuppressWarnings("deprecation")
public class HomeActivity extends TabActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TabHost host = (TabHost) findViewById(android.R.id.tabhost);

        TabHost.TabSpec tab1 = host.newTabSpec("Tab One");
        TabHost.TabSpec tab2 = host.newTabSpec("Tab Two");
        TabHost.TabSpec tab3 = host.newTabSpec("Tab Three");

        tab1.setIndicator("Book");
        tab1.setContent(new Intent(this, Tab1.class));

        tab2.setIndicator("Book List");
        tab2.setContent(new Intent(this, Tab2.class));

        tab3.setIndicator("Profile");
        tab3.setContent(new Intent(this, Tab3.class));

        host.addTab(tab1);
        host.addTab(tab2);
        host.addTab(tab3);

    }


}
