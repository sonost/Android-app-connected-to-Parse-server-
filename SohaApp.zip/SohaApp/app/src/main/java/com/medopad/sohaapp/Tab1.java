package com.medopad.sohaapp;


import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.SignUpCallback;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tab1 extends Activity {

    private EditText mName;
    private EditText mIsbn;
    private Button mAddButton;
    private Spinner mSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab1);


        mName = (EditText) findViewById(R.id.name);
        mIsbn = (EditText) findViewById(R.id.bookNum);
        mSpinner = (Spinner) findViewById(R.id.spin1);

        mAddButton = (Button) findViewById(R.id.bAdd);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(Tab1.this, android.R.layout.simple_list_item_1,
                getResources().getStringArray(R.array.Category));

        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(myAdapter);

        mAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String bookName = mName.getText().toString().trim();
                String bookIsbn = mIsbn.getText().toString().trim();
                String bookCategory = mSpinner.getSelectedItem().toString();

                if (bookName.length() == 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Tab1.this);
                    builder.setMessage("Sorry, book name can't be empty.");
                    builder.setTitle("Error");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }
                if (bookIsbn.length() == 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Tab1.this);
                    builder.setMessage("Book ISBN can't be empty.");
                    builder.setTitle("Error!");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }
                if (!bookIsbn.matches("\\d+")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(Tab1.this);
                    builder.setMessage("Book ISBN can only contain numbers.");
                    builder.setTitle("Error!");
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {
                            dialogInterface.dismiss();
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }

                //store user to parse
                ParseObject book = new ParseObject("Book");
                book.put("Name", bookName);
                book.put("ISBN", bookIsbn);
                book.put("Category", bookCategory);
                book.put("UserId", ParseUser.getCurrentUser().getObjectId());

                //book.saveInBackground();
                book.saveInBackground(new SaveCallback() {
                    @Override
                    public void done(ParseException e) {
                        if (e == null) {
                            //successfully added
                            AlertDialog.Builder builder = new AlertDialog.Builder(Tab1.this);
                            builder.setMessage("Book Added Successfully");
                            builder.setTitle("Success");
                            builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int which) {
                                    dialogInterface.dismiss();
                                }
                            });
                            AlertDialog dialog = builder.create();
                            dialog.show();
                            mName.setText("");
                            mIsbn.setText("");
                            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
                            //not resetting cateoory as user may be adding multiple books of the same category
                        } else {
                            Toast.makeText(Tab1.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });

            }
        });
    }
}
